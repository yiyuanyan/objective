//
//  getUserInfo.h
//  Login
//
//  Created by 何建新 on 16/3/10.
//  Copyright © 2016年 何建新. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface getUserInfo : NSObject
-(NSString *)getUser;
@end
