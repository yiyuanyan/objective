//
//  PartOneSecondColumnTableViewController.h
//  Login
//
//  Created by 何建新 on 16/3/10.
//  Copyright © 2016年 何建新. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PartOneSecondColumnTableViewController : UITableViewController
@property(nonatomic, copy)NSString *leval;
@property(nonatomic, copy)NSString *userInfo;
@property(nonatomic, copy)NSDictionary *cateDic;
@property(nonatomic, copy) NSArray *cateData;
@end
