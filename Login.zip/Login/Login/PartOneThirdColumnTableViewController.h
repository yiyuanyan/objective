//
//  PartOneThirdColumnTableViewController.h
//  Login
//
//  Created by 何建新 on 16/3/16.
//  Copyright © 2016年 何建新. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PartOneThirdColumnTableViewController : UITableViewController
@property(nonatomic, assign)NSInteger cid;
@property(nonatomic, copy) NSString *mobile;
@property(nonatomic, copy) NSDictionary *date;
@property(nonatomic, copy) NSArray *array;
@end
