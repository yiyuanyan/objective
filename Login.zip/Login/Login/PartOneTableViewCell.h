//
//  PartOneTableViewCell.h
//  Login
//
//  Created by 何建新 on 16/3/8.
//  Copyright © 2016年 何建新. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PartOneTableViewCell : UITableViewCell
@property(nonatomic, strong)UILabel *nameLabel;
@property(nonatomic, strong)UIImageView *imageNewView;
@end
