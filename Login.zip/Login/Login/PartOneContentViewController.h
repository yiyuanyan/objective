//
//  PartOneContentViewController.h
//  Login
//
//  Created by 何建新 on 16/3/18.
//  Copyright © 2016年 何建新. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PartOneContentViewController : UIViewController
@property(nonatomic, assign) int cid;
@property(nonatomic, strong)NSMutableDictionary *dataDic;
@end
