//
//  PartTwoContentTableViewController.h
//  Login
//
//  Created by 何建新 on 16/3/29.
//  Copyright © 2016年 何建新. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PartTwoContentTableViewController : UITableViewController
@property(nonatomic, copy)NSDictionary *cateDic;
@property(nonatomic, copy)NSString *mobile;
@end
