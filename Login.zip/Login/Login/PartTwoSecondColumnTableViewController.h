//
//  PartTwoSecondColumnTableViewController.h
//  Login
//
//  Created by 何建新 on 16/3/28.
//  Copyright © 2016年 何建新. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PartTwoSecondColumnTableViewController : UITableViewController
@property(nonatomic, copy)NSString *evalue;
@property(nonatomic, copy)NSString *mobile;
@property(nonatomic, copy)NSDictionary *cateDic;
@end
