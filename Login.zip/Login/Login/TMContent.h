//
//  TMContent.h
//  Login
//
//  Created by 何建新 on 16/4/5.
//  Copyright © 2016年 何建新. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TMContent : NSObject
@property(nonatomic, strong)NSString *audio;
@property(nonatomic, strong)NSString *english;
@property(nonatomic, strong)NSString *chines;
@property(nonatomic, assign)BOOL state;
@end
