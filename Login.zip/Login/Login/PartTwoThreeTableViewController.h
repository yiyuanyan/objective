//
//  PartTwoThreeTableViewController.h
//  Login
//
//  Created by 何建新 on 16/4/6.
//  Copyright © 2016年 何建新. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PartTwoThreeTableViewController : UITableViewController
@property(nonatomic, assign)NSDictionary *cateDic;
@property(nonatomic, assign)NSString *mobile;
@end
